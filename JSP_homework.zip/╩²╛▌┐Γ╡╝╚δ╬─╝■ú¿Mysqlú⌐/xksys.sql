-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2019-12-27 03:29:27
-- 服务器版本： 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xksys`
--

-- --------------------------------------------------------

--
-- 表的结构 `class`
--

CREATE TABLE `class` (
  `cno` char(4) COLLATE utf8_bin NOT NULL COMMENT '课程号',
  `cname` char(20) COLLATE utf8_bin NOT NULL COMMENT '课程名',
  `fee` int(10) NOT NULL COMMENT '学费'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='课程表';

--
-- 转存表中的数据 `class`
--

INSERT INTO `class` (`cno`, `cname`, `fee`) VALUES
('1', '学前教育', 2200),
('2', '小学课程辅导', 2800),
('3', '初中课程辅导', 3200),
('4', '高中课程辅导', 4000),
('5', '专科教育', 10000),
('6', '本科教育', 8000),
('7', '硕士课程讲义', 22000),
('8', '博士课程讲义', 50000);

-- --------------------------------------------------------

--
-- 表的结构 `sc`
--

CREATE TABLE `sc` (
  `cname` char(20) COLLATE utf8_bin NOT NULL COMMENT '课程名',
  `name` char(10) COLLATE utf8_bin NOT NULL COMMENT '购课人姓名'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='选课表';

--
-- 转存表中的数据 `sc`
--

INSERT INTO `sc` (`cname`, `name`) VALUES
('高中课程辅导', '张达');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `id` char(6) COLLATE utf8_bin NOT NULL COMMENT '用户名',
  `pw` char(6) COLLATE utf8_bin NOT NULL COMMENT '密码',
  `name` char(20) COLLATE utf8_bin NOT NULL COMMENT '姓名',
  `sex` char(2) COLLATE utf8_bin NOT NULL COMMENT '性别',
  `edu` char(12) COLLATE utf8_bin NOT NULL COMMENT '学历',
  `tel` char(20) COLLATE utf8_bin DEFAULT NULL COMMENT '联系方式',
  `money` int(255) DEFAULT NULL COMMENT '余额'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `pw`, `name`, `sex`, `edu`, `tel`, `money`) VALUES
('000000', '000000', '系统管理员', '男', '', NULL, NULL),
('1', '1', '张达', '男', '硕士研究生', '13870935102', 0),
('4', '1', '陈旭', '男', '专科', '15778592758', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`cno`);

--
-- Indexes for table `sc`
--
ALTER TABLE `sc`
  ADD PRIMARY KEY (`cname`,`name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
