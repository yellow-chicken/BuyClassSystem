package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class adminDeleuser {
	public boolean checkUser(String username){
		Connection connection =null;
		PreparedStatement pstmt=null;
		ResultSet resultSet=null;
		if(!username.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr= "select * from user where id='"+username+"'";
				pstmt=connection.prepareStatement(sqlstr);
				resultSet=pstmt.executeQuery();
				if(resultSet.next()){
					System.out.println("�Ѵ��ڴ��û�����");
					return true;
				}
				else
					System.out.println("�����ڸ��û�����");	
					return false;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean checksc(String username){
		Connection connection =null;
		PreparedStatement pstmt=null;
		PreparedStatement pstmt1=null;
		ResultSet resultSet=null;
		ResultSet resultSet1=null;
		if(!username.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr= "select name from user where id='"+username+"'";
				pstmt=connection.prepareStatement(sqlstr);
				resultSet=pstmt.executeQuery();
				if(resultSet.next()){
					String name=resultSet.getString("name");
					String sqlstr1="select * from sc where name='"+name+"'";
					pstmt1=connection.prepareStatement(sqlstr1);
					resultSet1=pstmt1.executeQuery();
					if(resultSet1.next())
					{
						System.out.println("���û�δ��Σ�");
						return false;
					}
					else{
						System.out.println("���û��ѽ�Σ�");
						return true;
					}
				}
				else
					System.out.println("�����ڸ��û�������");	
					return false;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean checkmoney(String username){
		Connection connection =null;
		PreparedStatement pstmt=null;
		ResultSet resultSet=null;
		if(!username.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr= "select money from user where id='"+username+"'";
				pstmt=connection.prepareStatement(sqlstr);
				resultSet=pstmt.executeQuery();
				if(resultSet.next()){
					int money=resultSet.getInt("money");
					if(money>0)
					{
						System.out.println("���û�����");
						return false;
					}
					else if(money==0)
					{
						System.out.println("�����Ϊ0��");
						return true;
					}
				}
				else
					System.out.println("�û������ڣ�");	
					return false;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public void deleuser(String username){
		Connection connection = null;
		PreparedStatement psmt = null;
		try {
			 connection=new conn().getcon();				 
			 String sql  ="delete from user where id=?";				 
			 psmt = (PreparedStatement) connection.prepareStatement(sql);
			 psmt.setString(1, username);
			 
			 psmt.executeUpdate();
			}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
