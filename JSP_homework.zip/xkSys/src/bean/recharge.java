package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class recharge {
	public void reCharge(String username,int charge){
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
			 connection=new conn().getcon();				 
			 String sql  ="update user set money=money+'" + charge + "' where id=?";				 
			 pstmt = (PreparedStatement) connection.prepareStatement(sql);
			 pstmt.setString(1, username);
			 
			 pstmt.executeUpdate();		 
			}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
