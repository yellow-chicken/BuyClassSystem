package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class buyClass {
	public classes checkClass(String cname) {
		   Connection connection =null;
		   PreparedStatement pstmt=null;
		   ResultSet resultSet=null;
		   classes c=new classes();
		
		  //��ֵ
		  try {
			connection=new conn().getcon();
			//��̬sql���
			String sql = "select cno from class where cname=?"; 
		    pstmt = (PreparedStatement) connection.prepareStatement(sql);
			pstmt.setString(1, cname);
			resultSet = pstmt.executeQuery();
			if(resultSet.next()){
				c=new classes();
				c.setcno(resultSet.getString("cno"));
				System.out.println("�ÿδ��ڣ�");
			}
			else{
				System.out.println("�ÿβ����ڣ�");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return c;
	}
	
	public boolean checkMoney(String username,String cname){
		Connection connection =null;
		PreparedStatement pstmt1=null;
		PreparedStatement pstmt2=null;

		ResultSet resultSet1=null;
		ResultSet resultSet2=null;

		if(!username.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr1= "select money from user where id='"+username+"' and money>0";
				String sqlstr2= "select fee from class where cname='"+cname+"'";

				pstmt1=connection.prepareStatement(sqlstr1);
				pstmt2=connection.prepareStatement(sqlstr2);

				resultSet1=pstmt1.executeQuery();
				resultSet2=pstmt2.executeQuery();
				
				if(resultSet1.next()){
					int moneyuser=resultSet1.getInt("money");
					if(resultSet2.next()){
						int fee=resultSet2.getInt("fee");
						int t=moneyuser-fee;
						if(t>=0){
							System.out.println("�����㣡");
							return true;
						}
						else{
							System.out.println("���㣡");
							return false;
						}
					}
				}
				else{
					System.out.println("���Ϊ0�����ֵ��");	
					return false;
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public void buyclass(String username,String cname){
		Connection connection = null;
		PreparedStatement pstmt1=null;
		PreparedStatement pstmt2=null;
		PreparedStatement pstmt3=null;
		PreparedStatement psmt=null;
		ResultSet resultSet1=null;
		ResultSet resultSet2=null;

		
		if(!username.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sql1 = "select name from user where id='"+username+"'";
				String sql2= "select fee from class where cname='"+cname+"'";
				
				pstmt1=connection.prepareStatement(sql1);
				pstmt2=connection.prepareStatement(sql2);
				
				resultSet1=pstmt1.executeQuery();
				resultSet2=pstmt2.executeQuery();
				
				if(resultSet1.next()){
					String name=resultSet1.getString("name");
						if(resultSet2.next()){
							int fee=resultSet2.getInt("fee");
							String sql3= "update user set money=money-'"+fee+"' where id='"+username+"'";
							pstmt3=connection.prepareStatement(sql3);							
							pstmt3.executeUpdate();
							
							String sql4  ="insert into sc(cname,name) values(?,?);";
							psmt = (PreparedStatement) connection.prepareStatement(sql4);					
							psmt.setString(1, cname);
							psmt.setString(2, name);
							psmt.executeUpdate();
					}
					else {
						System.out.println("�γ̲����ڣ�");
					}
				}
				else{
					System.out.println("�û������ڣ�");
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		else{
			System.out.println("�û�������Ϊ�գ�");
		}
	}
	
	public boolean checktime(String username,String cname){
		Connection connection =null;
		PreparedStatement pstmt1=null;
		PreparedStatement pstmt2=null;

		ResultSet resultSet1=null;
		ResultSet resultSet2=null;

		if(!username.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr1= "select name from user where id='"+username+"'";
				
				pstmt1=connection.prepareStatement(sqlstr1);

				resultSet1=pstmt1.executeQuery();
				
				if(resultSet1.next()){
					String name=resultSet1.getString("name");
					String sqlstr2= "select * from sc where cname= '"+cname+"' and name= '"+name+"' ";
					pstmt2=connection.prepareStatement(sqlstr2);
					resultSet2=pstmt2.executeQuery();
					if(resultSet2.next()){
						System.out.println("���û��Ѿ�ѡ���˿Σ�");
						return false;
					}
					else {
						System.out.println("���û�����ѡ�˿Σ�");
						return true;
					}
				}
				else{
					System.out.println("���û�ûѡ�Σ�");	
					return false;
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
}
