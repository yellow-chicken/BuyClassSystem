package bean;

public class classes {
	private String cno;
	private String cname;
	private String fee;
	public String getcno(){
		return cno;
	}
	public void setcno(String cno){
		this.cno = cno;
	}
	public String getcname(){
		return cname;
	}
	public void setcname(String cname){
		this.cname = cname;
	}
	public String getfee(){
		return fee;
	}
	public void setfee(String fee){
		this.fee = fee;
	}
}
