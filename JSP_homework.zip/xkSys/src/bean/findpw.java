package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class findpw {
	public boolean checktel(String tel){
		Connection connection =null;
		PreparedStatement pstmt=null;
		ResultSet resultSet=null;
			try{
				connection=new conn().getcon();
				String sqlstr= "select * from user where tel='"+tel+"'";
				pstmt=connection.prepareStatement(sqlstr);
				resultSet=pstmt.executeQuery();
				if(resultSet.next()){
					System.out.println("���û����ڣ�");
					return true;
				}
				else
					System.out.println("���û������ڣ�");	
					return false;
			}catch(Exception e){
				e.printStackTrace();
			}		
		return false;
	}
	
	public void changepw(String tel,String pw1){
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
			 connection=new conn().getcon();				 
			 String sql  ="update user set pw=? where tel=?";				 
			 pstmt = (PreparedStatement) connection.prepareStatement(sql);
			 pstmt.setString(1, pw1);
			 pstmt.setString(2, tel);
			 
			 pstmt.executeUpdate();		 
			}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
