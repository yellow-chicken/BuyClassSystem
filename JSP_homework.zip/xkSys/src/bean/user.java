package bean;

public class user {
	private String id;
	private String pw;
	private String name;
	private String sex;
	private String edu;
	private String tel;
	private int money;
	public String getid(){
		return id;
	}
	public void setid(String id){
		this.id = id;
	}
	public String getpw(){
		return pw;
	}
	public void setpw(String pw) {
		this.pw = pw;
	}
	public String getname(){
		return name;
	}
	public void setname(String name){
		this.name = name;
	}
	public String getsex(){
		return sex;
	}
	public void setsex(String sex){
		this.sex = sex;
	}
	public String getedu(){
		return edu;
	}
	public void setedu(String edu){
		this.edu = edu;
	}
	public String gettel(){
		return tel;
	}
	public void settel(String tel){
		this.tel = tel;
	}
	public int getmoney(){
		return money;
	}
	public void setmoney(int money){
		this.money = money;
	}
}
