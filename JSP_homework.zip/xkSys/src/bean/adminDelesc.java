package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class adminDelesc {
	public boolean checkUser(String username){
		Connection connection =null;
		PreparedStatement pstmt=null;
		ResultSet resultSet=null;
		if(!username.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr= "select * from user where id='"+username+"'";
				pstmt=connection.prepareStatement(sqlstr);
				resultSet=pstmt.executeQuery();
				if(resultSet.next()){
					System.out.println("�Ѵ��ڴ��û�����");
					return true;
				}
				else
					System.out.println("�����ڸ��û�����");	
					return false;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean checkSc(String username,String cname){
		Connection connection =null;
		PreparedStatement pstmt1=null;
		PreparedStatement pstmt2=null;
		ResultSet resultSet1=null;
		ResultSet resultSet2=null;
		if(!username.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr1= "select name from user where id='"+username+"'";
				pstmt1=connection.prepareStatement(sqlstr1);
				resultSet1=pstmt1.executeQuery();
				if(resultSet1.next()){
					String name=resultSet1.getString("name");
					String sqlstr2= "select * from sc where name='"+name+"' and cname='"+cname+"'";
					pstmt2=connection.prepareStatement(sqlstr2);
					resultSet2=pstmt2.executeQuery();
					if(resultSet2.next()){
						System.out.println("���û��ѹ���˿γ̣�");
						return true;
					}
					else {
						System.out.println("���û�δ����˿γ̣�");
						return false;
					}
					
				}
				else
					System.out.println("�����ڸ��û�����");	
					return false;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public void delesc(String username,String cname){
		Connection connection =null;
		PreparedStatement pstmt1=null;
		PreparedStatement pstmt2=null;
		ResultSet resultSet1=null;
		try {
			connection=new conn().getcon();
			String sqlstr1= "select name from user where id='"+username+"'";
			pstmt1=connection.prepareStatement(sqlstr1);
			resultSet1=pstmt1.executeQuery();
			if(resultSet1.next()){
				String name=resultSet1.getString("name");
				String sqlstr2  ="delete from sc where name=? and cname=?";				 
				pstmt2 = (PreparedStatement) connection.prepareStatement(sqlstr2);
				pstmt2.setString(1, name);
				pstmt2.setString(2, cname);
				
				pstmt2.executeUpdate();
			  }			 
			}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
