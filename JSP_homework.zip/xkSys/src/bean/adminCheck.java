package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class adminCheck {
	public user login(String username,String password) {
		   user u=null;
		   Connection connection =null;
		   PreparedStatement pstmt=null;
		   ResultSet resultSet=null;
		
		  //��ֵ
		  try {
			connection=new conn().getcon();
			//��̬sql���
			String sql = "select * from user where id=? and pw=? "; 
		    pstmt = (PreparedStatement) connection.prepareStatement(sql);
		    pstmt.setString(1, username);
			pstmt.setString(2, password);
			resultSet = pstmt.executeQuery();
			if(resultSet.next()){
				u=new user();
				u.setid(resultSet.getString("id"));
				u.setpw(resultSet.getString("pw"));
				System.out.println("��¼�ɹ���");
			}else{
				System.out.println("�û������������");
			}  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		 return u;	 
	}
}
