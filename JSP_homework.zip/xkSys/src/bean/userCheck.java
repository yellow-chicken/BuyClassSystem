package bean;

import java.sql.*;

public class userCheck {	
	public user login(String username,String password) {
		   user u=null;
		   Connection connection =null;
		   PreparedStatement pstmt=null;
		   ResultSet resultSet=null;
		
		  //��ֵ
		  try {
			connection=new conn().getcon();
			//��̬sql���
			String sql = "select * from user where id=? and pw=?"; 
		    pstmt = (PreparedStatement) connection.prepareStatement(sql);
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			resultSet = pstmt.executeQuery();
			if(resultSet.next()){
				u=new user();
				u.setid(resultSet.getString("id"));
				u.setpw(resultSet.getString("pw"));
				System.out.println("��¼�ɹ���");
			}else{
				System.out.println("�û������������");
			}  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		 return u;	 
	}
	
	public boolean checktel(String tel){
		Connection connection =null;
		PreparedStatement pstmt=null;
		ResultSet resultSet=null;
		if(!tel.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr= "select tel from user where tel='"+tel+"'";
				pstmt=connection.prepareStatement(sqlstr);
				resultSet=pstmt.executeQuery();
				if(resultSet.next()){
					System.out.println("�Ѵ��ڴ���ϵ��ʽ��");
					return false;
				}
				else
					System.out.println("�����ڸ���ϵ��ʽ������ע�ᣡ");	
					return true;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
		
	public boolean checkUser(String un){
		Connection connection =null;
		PreparedStatement pstmt=null;
		ResultSet resultSet=null;
		if(!un.equals(""))
		{
			try{
				connection=new conn().getcon();
				String sqlstr= "select id from user where id='"+un+"'";
				pstmt=connection.prepareStatement(sqlstr);
				resultSet=pstmt.executeQuery();
				if(resultSet.next()){
					System.out.println("�Ѵ��ڴ��û�����");
					return false;
				}
				else
					System.out.println("�����ڸ��û���������ע�ᣡ");	
					return true;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return false;
	}
	
	public void addUser(user user) {
		Connection connection = null;
		PreparedStatement psmt = null;
		try {
			 connection=new conn().getcon();				 
			 String sql  ="insert into user(id,pw,name,sex,edu,tel,money) values(?,?,?,?,?,?,0)";
				 
			 psmt = (PreparedStatement) connection.prepareStatement(sql);
				 
			 //����ʵ�������в�����ֵ
			 psmt.setString(1, user.getid());
			 psmt.setString(2, user.getpw());
			 psmt.setString(3, user.getname());
			 psmt.setString(4, user.getsex());
			 psmt.setString(5, user.getedu());
			 psmt.setString(6, user.gettel());
				 
			 psmt.executeUpdate();		 
			}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
