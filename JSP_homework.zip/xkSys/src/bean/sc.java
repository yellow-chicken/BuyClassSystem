package bean;

public class sc {
	private String cname;
	private String name;
	public String getcname(){
		return cname;
	}
	public void setcname(String cname){
		this.cname = cname;
	}
	public String getname(){
		return name;
	}
	public void setname(String name){
		this.name = name;
	}
}
