package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class searchClass {
	public classes searchClasses(String cno) {
		   classes c=null;
		   Connection connection =null;
		   PreparedStatement pstmt=null;
		   ResultSet resultSet=null;
		
		  //��ֵ
		  try {
			connection=new conn().getcon();
			//��̬sql���
			String sql = "select * from class where cno=?"; 
		    pstmt = (PreparedStatement) connection.prepareStatement(sql);
			pstmt.setString(1, cno);
			resultSet = pstmt.executeQuery();
			if(resultSet.next()){
				c=new classes();
				c.setcno(resultSet.getString("cno"));
				System.out.println("���ҳɹ���");
			}else{
				System.out.println("����ʧ�ܣ�");
			}  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return c;
	}
}
