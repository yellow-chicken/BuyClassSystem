package bean;

import java.sql.*;
import javax.swing.JOptionPane;


public class conn {
private Connection cn=null;
	
	public Connection getcon(){
		try {
			String url="jdbc:mysql://localhost:3306/xksys?useUnicode=true&characterEncoding=utf-8";
			Class.forName("com.mysql.jdbc.Driver");
			String userName ="root";
			String password="root";
			cn =DriverManager.getConnection(url,userName,password);
			if(cn==null)
            JOptionPane.showMessageDialog(null, "Can not connect to DB!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
            JOptionPane.showMessageDialog(null, "Can not connect to DB!");
			e.printStackTrace();
		}
	    return cn;	
	}
}
