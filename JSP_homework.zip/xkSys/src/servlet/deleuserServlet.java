package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.adminDeleuser;

public class deleuserServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public deleuserServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("username");
		adminDeleuser de=new adminDeleuser();
		boolean b1=de.checkUser(username);
		if(b1==true)
		{
			boolean b2=de.checksc(username);
			if(b2==true)
			{
				boolean b3=de.checkmoney(username);
				if(b3==true)
				{
					de.deleuser(username);
					out.print("<script>alert('ɾ���û���Ϣ�ɹ���');window.location.href='adminDeleuser.jsp'</script>");
				}
				else {
					out.print("<script>alert('���û���Ϊ0�����������룡');window.location.href='adminDeleuser.jsp'</script>");
				}
			}
			else {
				out.print("<script>alert('���û���δ��Σ����������룡');window.location.href='adminDeleuser.jsp'</script>");
			}
		}
		else{
			out.print("<script>alert('���û��������ڣ����������룡');window.location.href='adminDeleuser.jsp'</script>");
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
